tenancy_ocid= "ocid1.tenancy.oc1..aaaaaaaaqv5so5lzw6up6vgv4x4rrv3bx3yo55u4o77fv5ccoie3g2j6dsjq"

user_ocid="ocid1.user.oc1..aaaaaaaag7wxfbq334mwdofyu2y5aj6uhukug4u4lsmh3ct7e4rgvqybsmeq"

fingerprint="12:b6:57:86:fc:06:e4:65:bd:37:4f:81:9d:26:a1:6a"

private_key_path="C:\\Users\\MSI\\Documents\\Tareas\\P.S.3\\terra\\lmw3006036@est.univalle.edu-2026-10-19T12_19_24.158Z.pem"

region="sa-santiago-1"

compartment_ocid="ocid1.tenancy.oc1..aaaaaaaaqv5so5lzw6up6vgv4x4rrv3bx3yo55u4o77fv5ccoie3g2j6dsjq"

ubuntu_2404_image_ocid="ocid1.image.oc1.sa-santiago-1.aaaaaaaah5xnmg2znzgnnfeo53fzedousqye36rpseqadoyspr3m5ahrwf2q"

ssh_public_key="ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDYfoUyn8TBU11RkwPXHquuB78LFcc6T3bYPRCMMU79MOabdf6r27ewRaUEAXCVn+z1f+Z7Ov3LGEPViyjIU3OF//6B0ltppv5/TJbDOLNuRPtOLLETEHZ0IpOv0lTLJsIGnih7nJ+21Vn2406670qmiyBtMCIAn6WJ5oVz6jBilLnUxg4Y48/BWcS4eH1HlXSAfeHhB/+aMJKMKJFY0YLxMGVwRpYadanV+E4L7OcotwSpVqzooVEifR82SP/LDPu02W4COLu1ufrYdDWUwFuIwNt06BOkqRflKSJ1SQxdUBbFiWWFJ8sTLlprUOikZq53Tf1/gcSEOzpy9J3V3kpv ssh-key-2026-10-19"

subnet_ocid="ocid1.subnet.oc1.sa-santiago-1.aaaaaaaaxci6swvrlo4r6du4rfgj5mkkanl7rzep3myx2c6iybjfctqnxl4a"

availability_domain="YgCn:SA-SANTIAGO-1-AD-1"